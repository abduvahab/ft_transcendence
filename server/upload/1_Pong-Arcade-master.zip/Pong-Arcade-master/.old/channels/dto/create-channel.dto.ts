// src/channels/dto/create-channel.dto.ts

export class CreateChannelDto {
    name: string;
    ownerId: number;
  }