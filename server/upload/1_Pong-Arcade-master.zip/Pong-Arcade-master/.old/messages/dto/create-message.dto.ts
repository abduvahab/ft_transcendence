// src/messages/dto/create-message.dto.ts

export class CreateMessageDto {
    userId: number;
    content: string;
  }