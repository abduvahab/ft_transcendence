// src/auth/dto/login.dto.tsloginDto

export class LoginDto {
    username: string;
    password: string;
  }