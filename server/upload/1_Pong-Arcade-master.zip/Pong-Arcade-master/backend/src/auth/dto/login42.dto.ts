export class Login42Dto {
	readonly code: string;
}
