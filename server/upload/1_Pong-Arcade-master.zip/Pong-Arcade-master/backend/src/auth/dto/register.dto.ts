// src/auth/dto/register.dto.ts

export class RegisterDto {
    readonly username: string;
    readonly password: string;
    // Ajoutez d'autres champs si nécessaire, comme email, etc.
}