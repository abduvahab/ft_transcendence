export class Register42Dto {
	readonly code: string;
	readonly username: string;
}
