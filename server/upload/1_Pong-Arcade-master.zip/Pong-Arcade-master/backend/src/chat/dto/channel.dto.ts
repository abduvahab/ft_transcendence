export class NewChannelDto {
	readonly name: string;
	readonly type: string;
	readonly password: string;
}
