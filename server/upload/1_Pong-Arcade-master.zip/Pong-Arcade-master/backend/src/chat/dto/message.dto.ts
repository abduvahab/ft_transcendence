export class GetMessageDto {
	readonly channel: number;
	readonly from: Date;
}
