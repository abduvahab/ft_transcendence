// src/users/dto/block-user.dto.ts

export class BlockUserDto {
    userId: number;
    blockedUserId: number;
}