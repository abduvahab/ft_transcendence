export class UploadAvatarDto {
	readonly data: string;
}
