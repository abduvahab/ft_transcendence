import React from 'react'
import Search from './Search'
import Navbar from './Navbar'

const Channels = () => {
    return (
        <div>
             <div className='chatsC'>
            <div className="userChatC">
                <img className='imageC' src="https://images.pexels.com/photos/19154211/pexels-photo-19154211/free-photo-of-a-man-playing-a-bass-at-a-wedding.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load" alt="" />
                <div className='userChatInfoC'>
                    <span>Channels 1</span>
                    <h1>Hello</h1>
                </div>
            </div>
            <div className="userChatC">
                <img className='imageC' src="https://images.pexels.com/photos/19154211/pexels-photo-19154211/free-photo-of-a-man-playing-a-bass-at-a-wedding.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load" alt="" />
                <div className='userChatInfoC'>
                    <span>Channels 2</span>
                    <h1>Hello</h1>
                </div>
            </div>
            <div className="userChatC">
                <img className='imageC' src="https://images.pexels.com/photos/19154211/pexels-photo-19154211/free-photo-of-a-man-playing-a-bass-at-a-wedding.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load" alt="" />
                <div className='userChatInfoC'>
                    <span>Channels 3</span>
                    <h1>Hello</h1>
                </div>
            </div>
        </div>
        </div>
    );
};

export default Channels