import React from 'react'
import Messages from './Messages'
import Input from './Input'
import More from "../../assets/more.png"


const Chat = () => {
    return (
        <div className='chatC'>
            <div className='chatInfoC'>
                <span>Test2</span>
                <div className='chatIconsC'>
                    <img src={More} alt="" className='imageC' />
                </div>
            </div>
            <Messages />
            <Input/>
        </div>

    );
};

export default Chat