import React from 'react'

const Sidebar = () => {
    return (
        <div className='chatsC'>
            <div className="userChatC">
                <img className='imageC' src="https://images.pexels.com/photos/9210844/pexels-photo-9210844.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load" alt="" />
                <div className='userChatInfoC'>
                    <span>Test1</span>
                    <h1>Hello</h1>
                </div>
            </div>
            <div className="userChatC">
                <img className='imageC' src="https://images.pexels.com/photos/9210844/pexels-photo-9210844.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load" alt="" />
                <div className='userChatInfoC'>
                    <span>Test1</span>
                    <h1>Hello</h1>
                </div>
            </div>
            <div className="userChatC">
                <img className='imageC' src="https://images.pexels.com/photos/9210844/pexels-photo-9210844.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load" alt="" />
                <div className='userChatInfoC'>
                    <span>Test1</span>
                    <h1>Hello</h1>
                </div>
            </div>
        </div>
    );
};

export default Sidebar
