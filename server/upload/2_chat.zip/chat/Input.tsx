import React from 'react'

const Input = () => {
    return (
        <div className='inputC'>
            <input type='text' className='inputSend text-black' placeholder='Type something...' />
            <div>
                <button className='border-none px-4 py-2 text-white bg-blue-500 cursor-pointer'>Send</button>
            </div>
        </div>
    );
};

export default Input