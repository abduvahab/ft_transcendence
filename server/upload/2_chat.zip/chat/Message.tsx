import React, {useEffect} from 'react'

const Message = () => {
    return (
        <div className='messageC ownerC'>
            <div className='messageInfoC'>
                <img
                    className='imageC'
                    src="https://images.pexels.com/photos/19180584/pexels-photo-19180584/free-photo-of-lost-in-the-melody-hooded-handpan-player-creating-magical-music.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load"
                    alt=""
                />
                <span>just now</span>
            </div>
            <div className='messageContentC'>
                <p className='pC text-black'>hello</p>
                <img className='imageC' src="https://images.pexels.com/photos/19180584/pexels-photo-19180584/free-photo-of-lost-in-the-melody-hooded-handpan-player-creating-magical-music.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load" alt="" />
            </div>
        </div>
    );
};

export default Message