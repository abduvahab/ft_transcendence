import React from 'react'
import icon from '../../assets/icon.png';

const Rightbar = () => {
    return (
        <div className='sidebarC'>
            <div className="flex items-center justify-center">
                 <img className="rounded-full border-4 border-solid border-gray-800 h-40 w-40 mt-20 object-cover" src={icon} alt="User icon" />
            </div>
                 <div className="flex justify-center mt-5">
                    <button className="rounded-full bg-blue-500 text-white px-4 py-2 mr-2">Block</button>
                    <button className="rounded-full bg-green-500 text-white px-4 py-2">View Profile</button>
                </div>
        </div>
    );
};

export default Rightbar