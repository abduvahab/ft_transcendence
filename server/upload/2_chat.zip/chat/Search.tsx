import React from 'react';
import '../../css/chat.css';

const Search: React.FC = () => {
  return (
    <div className='searchC'>
      <div className='searchFormC'>
        <input className='inputC' placeholder='Find a user' type="text"/>
      </div>
    </div>
  );
};

export default Search;
