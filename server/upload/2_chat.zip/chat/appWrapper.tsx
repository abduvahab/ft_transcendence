// AppWrapper.tsx
import React from 'react';
import Sidebar from './Sidebar';
import Rightbar from './Rightbar'
import Chat from './Chat';
import '../../css/chat.css'

const AppWrapper: React.FC = () => {
  return (
    <>
    <div className='homeC'>
        <div className='containerC'>
            <Sidebar />
            <Chat />
            <Rightbar />
        </div>
    </div>
    </>
  );
};

export default AppWrapper;